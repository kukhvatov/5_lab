from sklearn.linear_model import LogisticRegression
import numpy as np
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import GridSearchCV
import mlflow
import pandas as pd
from mlflow.models import infer_signature
import warnings
import pickle
warnings.filterwarnings("ignore")

def get_metrics_lg(actual, pred):
    rmse = np.sqrt(mean_squared_error(actual, pred))
    mae = mean_absolute_error(actual, pred)
    r2 = r2_score(actual, pred)
    return rmse, mae, r2

def train(config):
    df_train = pd.read_csv(config['data_split']['trainset_path'])
    df_test = pd.read_csv(config['data_split']['testset_path'])
    print(df_train.shape)

    X_train, y_train = df_train.drop(columns=['popularity']).values, df_train['popularity'].values
    X_val, y_val = df_test.drop(columns=['popularity']).values, df_test['popularity'].values

    params = {"penalty": config['train']['penalty'],
          'C': config['train']['C']
     }

    mlflow.set_experiment("Spotify dataset experiment LR")
    with mlflow.start_run():
        lg = LogisticRegression(random_state=42)
        clf = GridSearchCV(lg, params, cv = config['train']['cv'])
        clf.fit(X_train, y_train)
        best = clf.best_estimator_

        y_pred = best.predict(X_val)

        (rmse, mae, r2)  = get_metrics_lg(y_val, y_pred)

        penalty = best.penalty
        C = best.C

        mlflow.log_param("penalty", penalty)
        mlflow.log_param("C", C)
        mlflow.log_metric("rmse", rmse)
        mlflow.log_metric("r2", r2)
        mlflow.log_metric("mae", mae)
        
        predictions = best.predict(X_train)
        signature = infer_signature(X_train, predictions)
        mlflow.sklearn.log_model(lg, "model", signature=signature)
    
        with open(config['train']['model_path'], "wb") as f:
            pickle.dump(best, f)
