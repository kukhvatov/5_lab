from pandas._config import config
from sklearn.preprocessing import LabelEncoder
import pandas as pd
import numpy as np
import yaml
import sys
import os
sys.path.append(os.getcwd())

from src.loggers import get_logger

def load_config(config_path):
    with open(config_path) as conf_file:
        config = yaml.safe_load(conf_file)
    return config

def clear_data(path):
    df = pd.read_csv(path)
    df = df.drop(columns=['track_id', 'track_name', 'album_name'], axis=1)
    df['explicit'] = df['explicit'].astype(np.int64)
    category_columns = ['artists', 'track_genre']

    for col in category_columns:
        le = LabelEncoder()
        df[col] = le.fit_transform(df[col])
    df = df.drop(columns=['loudness', 'energy', 'danceability', 
                      'valence', 'acousticness','instrumentalness'],
             axis=1)
    return df

def get_data(data):
    df = data.copy()
    X, y = df.drop(columns=['popularity']), df['popularity']
    return X, y

def featurize(data, config) -> None:
    logger = get_logger("FEATURIZE")
    logger.info("Create features")
    data['duration_min'] = data['duration_ms'] / 3600
    data['explicit on liveness'] = data['explicit'] * data['liveness'] // 100
    
    features_path = config['featurize']['features_path']
    data.to_csv(features_path, index=False)

if __name__ == '__main__':
    config = load_config("./src/config.yaml")
    df_prep = clear_data(config['data_load']['dataset_csv'])
    df_new_features = featurize(df_prep, config)